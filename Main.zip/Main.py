from GUI import GUI

def main():
    app = GUI()


if __name__ == "__main__":
    main()

